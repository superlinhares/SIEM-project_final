<?php 

include_once('../../config/init.php');
include_once($BASE_DIR . '/database/user.php');

if(isset($_SESSION['username'])) {
	$password = getUserPassword($_SESSION['username']);
	$smarty->assign('password', $password);
	$smarty->display('account/user/password.tpl');
}
else {
	header('Location: '. $BASE_URL);
}

?>