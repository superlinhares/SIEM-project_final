<?php 

include_once('../../config/init.php');
include_once($BASE_DIR . '/database/user.php');

if(isset($_SESSION['username'])) {
	$address = getUserAddress($_SESSION['username']);
	$smarty->assign('address', $address);
	$smarty->display('account/user/address.tpl');
}
else {
	header('Location: '. $BASE_URL);
}

?>