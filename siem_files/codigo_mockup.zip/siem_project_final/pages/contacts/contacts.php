<?php 
  include_once('../../config/init.php');

  $smarty->display('contacts/contacts.tpl');
?>