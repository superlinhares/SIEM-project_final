<?php 
  include_once('../../config/init.php');
  include_once($BASE_DIR . '/database/user.php');

  if (isset($_POST['change'])) {

  	$username = $_SESSION['username'];
  	$userRealname = $_POST['user-name'];
    $userEmail = $_POST['user-email'];
    $userDob = $_POST['user-dob'];
    $userPhone = $_POST['user-phone'];

  	if(!empty($userRealname) || !empty($userEmail) || !empty($userDob) || !empty($userPhone)) {
  	  
      if(!empty($userRealname)) {
        $sql = 'UPDATE users
                SET real_name=?
                WHERE username=?';
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($userRealname, $username));
      }

      if(!empty($userEmail)) {
        $sql = 'UPDATE users
                SET email=?
                WHERE username=?';
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($userEmail, $username));
      }

      if(!empty($userDob)) {
        $sql = 'UPDATE users
                SET dob=?
                WHERE username=?';
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($userDob, $username));
      }

      if(!empty($userPhone)) {
        $sql = 'UPDATE users
                SET tel=?
                WHERE username=?';
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($userPhone, $username));
      }

      $_SESSION['success_messages'][] = 'Campos alterados com sucesso!'; 
      header('Location: ' . $_SERVER['HTTP_REFERER']);
	    exit();
  	} else {

  		$_SESSION['error_messages'][] = 'Deve preencher algum campo'; 
      header('Location: ' . $_SERVER['HTTP_REFERER']);
      exit();
  	}
  }

  ?>