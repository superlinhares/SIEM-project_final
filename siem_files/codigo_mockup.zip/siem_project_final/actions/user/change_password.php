<?php 
  include_once('../../config/init.php');
  include_once($BASE_DIR . '/database/user.php');

  if (isset($_POST['change'])) {

  	$username = $_SESSION['username'];
  	$userPassword = $_POST['user-password'];
    $newUserPassword = $_POST['new-user-password'];
    $newUserPassword2 = $_POST['new-user-password2'];


  	if(empty($userPassword) || empty($newUserPassword) || empty($newUserPassword2)) {
  	  $_SESSION['error_messages'][] = 'Os campos devem ser preenchidos'; 
      header('Location: ' . $_SERVER['HTTP_REFERER']);
	    exit;
  	} else {

      if(!isLoginCorrect($username, $userPassword)) {
        $_SESSION['error_messages'][] = 'Password atual errada'; 
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;

      } else  {
          if($newUserPassword != $newUserPassword2) {
          $_SESSION['error_messages'][] = 'Repita novamente a nova password'; 
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit;

        } else {

          $sql = 'UPDATE users
                  SET password=?
                  WHERE username=?';
          $stmt = $conn->prepare($sql);
          $stmt->execute(array(sha1($newUserPassword), $username));
          $_SESSION['success_messages'] = 'Password alterada com sucesso';
          header('Location: ' . $_SERVER['HTTP_REFERER']);
          exit();

        }
      }
  	}
  }
  ?>