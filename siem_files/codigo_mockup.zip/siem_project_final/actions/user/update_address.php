<?php 
  include_once('../../config/init.php');
  include_once($BASE_DIR . '/database/user.php');

  if (isset($_POST['change'])) {

  	$username = $_SESSION['username'];
  	$userAddress = $_POST['user-address'];

  	if(empty($userAddress)) {
  	  $_SESSION['error_messages'][] = 'O campo deve ser preenchido'; 
      header('Location: ' . $_SERVER['HTTP_REFERER']);
	    exit;
  	} else {

  		$sql = 'UPDATE users
  				SET address=?
  				WHERE username=?';
  		$stmt = $conn->prepare($sql);
  		$stmt->execute(array($userAddress, $username));
  		$_SESSION['success_messages'] = 'Morada alterada com sucesso';
    	header('Location: ' . $_SERVER['HTTP_REFERER']);
  		exit();
  	}
  }

  ?>