<?php
/* Smarty version 3.1.33, created on 2019-01-15 15:51:55
  from 'C:\Bitnami\wampstack-7.1.25-0\apache2\htdocs\siem_project_final\templates\common\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c3e721b06fb83_59224621',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2c689c711d8e4ac7809a85d6c66be4e8eb0d0619' => 
    array (
      0 => 'C:\\Bitnami\\wampstack-7.1.25-0\\apache2\\htdocs\\siem_project_final\\templates\\common\\footer.tpl',
      1 => 1547577950,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c3e721b06fb83_59224621 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- End of content -->
  </div>
<!-- Still container -->
	<footer id="footer">

		<section class="footer-start">
      <header class="footer-start-header">
        <h1>Vamos Começar!</h1>
      </header>
			<footer class="footer-start-footer">
        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/store/list_categories.php"><button class="default-button">Fazer Pedido</button></a>	
      </footer>
		</section>

		<section class="footer-container">	
			<div class="footer-left">
				<a href="index.php"><img class="footer-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/logo_footer.png"></a>
			</div>
			<nav class="footer-center">
        <h1><a class="link-header" href="index.php">A Marmita da Rita</a></h1>
        <ul class="link-info">
          <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/about/about.php">Sobre</a></li>
          <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/store/list_categories.php">Loja</a></li>
          <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/contacts/contacts.php">Contactos</a></li>
          <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/pages/faq/faq.php">FAQ</a></li>        
        </ul>	
			</nav>

			<div class="footer-right">
				<h1 class="footer-header">Sigam-nos</h1>
        <a href="https://facebook.com" target="_blank"><img class="social-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/face.png"></a>
        <a href="https://instagram.com" target="_blank"><img class="social-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/insta.png"></a>
        <a href="https://linkedin.com" target="_blank"><img class="social-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/in.png"></a>
			</div>

      <div class="footer-siem">        
        <h1>SIEM - Documentação</h1>
        <h2>Browser: Google Chrome</h2>
        <br>        
        <h2>Admin login</h2>
        <br>        
        <h3>username: admin</h3>
        <h3>password: password</h3>
        <br>
        <h2>User login</h2>
        <br>        
        <h3>username: user</h3>
        <h3>password: password</h3>
        <br>        
        <h2>Código + Mockup <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/siem_files/codigo_mockup.zip" download><i class="fas fa-download" style="color: #83BB66"></i></a></h2>   
      </div>
		</section>

		<section class="footer-end">
			<p class="p-footer">&copy; Pedro Linhares Oliveira - Gonçalo Soares Lemos - SIEM 2018</p>
		</section>
	<!-- End of div #container-->
	</footer>	
</div>
</body>
</html><?php }
}
