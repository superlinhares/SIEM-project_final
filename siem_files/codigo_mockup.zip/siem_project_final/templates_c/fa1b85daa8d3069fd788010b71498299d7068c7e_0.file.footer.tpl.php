<?php
/* Smarty version 3.1.33, created on 2018-12-16 00:01:27
  from 'C:\inetpub\wwwroot\project_final\templates\common\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c156ba7bba6d4_10314286',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fa1b85daa8d3069fd788010b71498299d7068c7e' => 
    array (
      0 => 'C:\\inetpub\\wwwroot\\project_final\\templates\\common\\footer.tpl',
      1 => 1544907386,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c156ba7bba6d4_10314286 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- End of content -->
  </div>
<!-- Still container -->
	<footer id="footer">

		<section class="footer-start">
      <header class="footer-start-header">
        <h1>Vamos Começar!</h1>
      </header>
			<footer class="footer-start-footer">
        <a href="store.php"><button class="default-button">Fazer Pedido</button></a>	<!--FIXME: fix store path-->	
      </footer>
		</section>

		<section class="footer-container">	
			<div class="footer-left">
				<a href="index.php"><img class="footer-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/logo_footer.png"></a>
			</div>
      <!-- FIXME: fix links -->
			<nav class="footer-center">
        <h1><a class="link-header" href="index.php">A Marmita da Rita</a></h1>
        <ul class="link-info">
          <li><a href="about.php">Sobre</a></li>
          <li><a href="store.php">Loja</a></li>
          <li><a href="contact.php">Contactos</a></li>
          <li><a href="faq.php">FAQ</a></li>        
        </ul>	
			</nav>

			<div class="footer-right">
				<h1 class="footer-header">Sigam-nos</h1>
        <a href="https://facebook.com" target="_blank"><img class="social-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/face.png"></a>
        <a href="https://instagram.com" target="_blank"><img class="social-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/insta.png"></a>
        <a href="https://linkedin.com" target="_blank"><img class="social-logo" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
/img/in.png"></a>
			</div>
		</section>

		<div class="footer-end">
			<p class="p-footer">&copy; Pedro Linhares Oliveira - Gonçalo Soares Lemos - SIEM 2018</p>
		</div>
	<!-- End of div #container-->
	</footer>	
</div>
</body>
</html><?php }
}
