<?php 
    header('Location: pages/home/home.php');
?>